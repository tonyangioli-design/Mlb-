import streamlit as st
from model_utils import get_today_predictions

st.set_page_config(page_title="MLB Win Probability Model", layout="wide")

st.title("⚾ MLB Win Probability & Odds Edge Model")
st.write("This tool shows win probabilities, fair odds, and edges for today's games.")

data = get_today_predictions()
if data.empty:
    st.warning("No games found or data not available.")
else:
    st.dataframe(data, use_container_width=True)
